interface InterestPillProps {
  label: string;
}

export function InterestPill({ label }: InterestPillProps) {
  return (
    <div
      className="px-3 py-1.5 rounded-full text-xs"
      style={{
        background: 'var(--bg-elevated)',
        color: 'var(--text-secondary)',
      }}
    >
      {label}
    </div>
  );
}
