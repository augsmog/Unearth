import { Compass } from 'lucide-react';
import { motion } from 'motion/react';

interface PackProps {
  variant?: 'sealed' | 'opening';
  color?: 'gold' | 'blue' | 'purple';
  isSelected?: boolean;
  onClick?: () => void;
}

export function Pack({ variant = 'sealed', color = 'gold', isSelected = false, onClick }: PackProps) {
  // Color scheme based on pack type
  const colorSchemes = {
    gold: {
      primary: '#FFD700',
      gradient: 'linear-gradient(135deg, #2A1810 0%, #1a1f3a 50%, #0a0e27 100%)',
      border: 'rgba(255, 215, 0, 0.4)',
      glow: 'rgba(255, 215, 0, 0.3)',
    },
    blue: {
      primary: '#00D4FF',
      gradient: 'linear-gradient(135deg, #0A1828 0%, #1a2f3a 50%, #0a0e27 100%)',
      border: 'rgba(0, 212, 255, 0.4)',
      glow: 'rgba(0, 212, 255, 0.3)',
    },
    purple: {
      primary: '#B794F6',
      gradient: 'linear-gradient(135deg, #1A0A28 0%, #2a1f3a 50%, #0a0e27 100%)',
      border: 'rgba(183, 148, 246, 0.4)',
      glow: 'rgba(183, 148, 246, 0.3)',
    },
  };

  const scheme = colorSchemes[color];

  if (variant === 'opening') {
    return (
      <div className="relative w-[240px] h-[320px] sm:w-[280px] sm:h-[380px] md:w-[320px] md:h-[420px] lg:w-[360px] lg:h-[460px]">
        {/* Left half of torn pack */}
        <motion.div
          initial={{ x: 0, rotate: 0 }}
          animate={{ x: -100, rotate: -15 }}
          transition={{ duration: 0.4 }}
          className="absolute left-0 top-0 w-1/2 h-full overflow-hidden"
          style={{
            background: scheme.gradient,
            border: `2px solid ${scheme.border}`,
            borderRadius: 'var(--radius-md)',
            transformOrigin: 'right center',
            boxShadow: `0 0 30px ${scheme.glow} inset`,
          }}
        >
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-4 left-4 w-16 h-16 border-2 border-current rotate-45" 
              style={{ borderColor: scheme.primary }} />
            <div className="absolute bottom-8 right-4 w-12 h-12 border-2 border-current rounded-full"
              style={{ borderColor: scheme.primary }} />
          </div>
        </motion.div>

        {/* Right half of torn pack */}
        <motion.div
          initial={{ x: 0, rotate: 0 }}
          animate={{ x: 100, rotate: 15 }}
          transition={{ duration: 0.4 }}
          className="absolute right-0 top-0 w-1/2 h-full overflow-hidden"
          style={{
            background: scheme.gradient,
            border: `2px solid ${scheme.border}`,
            borderRadius: 'var(--radius-md)',
            transformOrigin: 'left center',
            boxShadow: `0 0 30px ${scheme.glow} inset`,
          }}
        >
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-8 right-4 w-16 h-16 border-2 border-current rotate-45"
              style={{ borderColor: scheme.primary }} />
            <div className="absolute bottom-4 left-4 w-12 h-12 border-2 border-current rounded-full"
              style={{ borderColor: scheme.primary }} />
          </div>
        </motion.div>

        {/* Central glow */}
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="absolute inset-0 flex items-center justify-center"
        >
          <div
            className="w-32 h-32 rounded-full blur-3xl"
            style={{
              background: `radial-gradient(circle, ${scheme.primary} 0%, transparent 70%)`,
            }}
          />
        </motion.div>
      </div>
    );
  }

  return (
    <motion.div
      onClick={onClick}
      whileHover={onClick ? { scale: 1.05, y: -12 } : { y: -8 }}
      whileTap={onClick ? { scale: 0.98 } : {}}
      animate={{
        y: isSelected ? -8 : [0, -8, 0],
        scale: isSelected ? 1.05 : 1,
      }}
      transition={{
        duration: 3,
        repeat: isSelected ? 0 : Infinity,
        ease: 'easeInOut',
      }}
      className={`relative w-[160px] h-[220px] md:w-[200px] md:h-[280px] rounded-xl overflow-hidden ${onClick ? 'cursor-pointer' : ''}`}
      style={{
        background: scheme.gradient,
        border: `3px solid ${isSelected ? scheme.primary : scheme.border}`,
        boxShadow: isSelected 
          ? `0 0 80px ${scheme.glow} inset, 0 8px 32px rgba(0, 0, 0, 0.6), 0 0 40px ${scheme.glow}`
          : `0 0 60px ${scheme.glow} inset, 0 8px 32px rgba(0, 0, 0, 0.6)`,
      }}
    >
      {/* Ornate corner decorations */}
      <div className="absolute top-0 left-0 w-12 h-12 border-l-2 border-t-2 opacity-30"
        style={{ borderColor: scheme.primary }} />
      <div className="absolute top-0 right-0 w-12 h-12 border-r-2 border-t-2 opacity-30"
        style={{ borderColor: scheme.primary }} />
      <div className="absolute bottom-0 left-0 w-12 h-12 border-l-2 border-b-2 opacity-30"
        style={{ borderColor: scheme.primary }} />
      <div className="absolute bottom-0 right-0 w-12 h-12 border-r-2 border-b-2 opacity-30"
        style={{ borderColor: scheme.primary }} />

      {/* Archaeological pattern texture */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-6 left-6 w-16 h-16 border-2 border-current rotate-45"
          style={{ borderColor: scheme.primary }} />
        <div className="absolute top-12 right-8 w-12 h-12 border-2 border-current rounded-full"
          style={{ borderColor: scheme.primary }} />
        <div className="absolute bottom-12 left-10 w-14 h-14 border-2 border-current rotate-12"
          style={{ borderColor: scheme.primary }} />
        <div className="absolute bottom-6 right-6 w-8 h-8 border-2 border-current rounded-full"
          style={{ borderColor: scheme.primary }} />
      </div>

      {/* Glowing center emblem with ring */}
      <div className="absolute inset-0 flex items-center justify-center">
        <motion.div
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute w-20 h-20 md:w-24 md:h-24 rounded-full border-2 opacity-30"
          style={{ borderColor: scheme.primary, borderStyle: 'dashed' }}
        />
        <div
          className="w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center relative"
          style={{
            background: `radial-gradient(circle, ${scheme.glow} 0%, transparent 70%)`,
          }}
        >
          <div className="absolute inset-0 rounded-full border-2 opacity-50"
            style={{ borderColor: scheme.primary }} />
          <Compass
            size={40}
            style={{ color: scheme.primary }}
            strokeWidth={1.5}
          />
        </div>
      </div>

      {/* Title badge */}
      <div className="absolute top-4 left-0 right-0 text-center">
        <div className="inline-block px-4 py-1.5 rounded-lg relative"
          style={{
            background: `linear-gradient(135deg, ${scheme.glow} 0%, rgba(255, 215, 0, 0.05) 100%)`,
            border: `1px solid ${scheme.border}`,
          }}>
          <p className="text-xs md:text-sm font-bold tracking-widest uppercase"
            style={{ 
              color: scheme.primary,
              textShadow: `0 0 10px ${scheme.glow}`,
            }}>
            UNEARTHED
          </p>
        </div>
      </div>

      {/* Bottom text */}
      <div className="absolute bottom-4 left-0 right-0 text-center">
        <div className="inline-block px-3 py-1 rounded-lg"
          style={{
            background: 'rgba(0, 0, 0, 0.4)',
            border: `1px solid ${scheme.border}`,
          }}>
          <p className="text-[10px] md:text-xs tracking-wide uppercase"
            style={{ color: scheme.primary }}>
            5 Sites
          </p>
        </div>
      </div>
    </motion.div>
  );
}