import { Menu, Flame } from 'lucide-react';

interface HeaderProps {
  streak?: number;
}

export function Header({ streak = 3 }: HeaderProps) {
  return (
    <header
      className="fixed top-0 left-0 right-0 h-14 flex items-center justify-between px-4 z-50"
      style={{ background: 'var(--bg-primary)' }}
    >
      <button className="p-2">
        <Menu size={24} style={{ color: 'var(--text-secondary)' }} />
      </button>

      <div
        className="text-xl tracking-[0.15em] uppercase"
        style={{ 
          color: 'var(--text-primary)',
          fontFamily: 'Rajdhani, sans-serif',
          fontWeight: 700,
          letterSpacing: '0.25em',
        }}
      >
        unearthed
      </div>

      <div className="relative">
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center"
          style={{ background: 'var(--accent-secondary)' }}
        >
          <span
            className="text-sm"
            style={{ color: 'var(--text-primary)' }}
          >
            U
          </span>
        </div>
        {streak > 0 && (
          <div
            className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center"
            style={{ background: 'var(--accent-gold)' }}
          >
            <Flame size={12} style={{ color: 'var(--bg-primary)' }} fill="currentColor" />
          </div>
        )}
      </div>
    </header>
  );
}