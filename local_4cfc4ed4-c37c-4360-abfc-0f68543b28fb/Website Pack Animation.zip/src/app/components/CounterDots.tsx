import { motion } from 'motion/react';

interface CounterDotsProps {
  total: number;
  filled: number;
  size?: 'small' | 'medium';
}

export function CounterDots({ total, filled, size = 'small' }: CounterDotsProps) {
  const dotSize = size === 'small' ? 8 : 12;

  return (
    <div className="flex items-center gap-2">
      {Array.from({ length: total }).map((_, index) => (
        <motion.div
          key={index}
          animate={
            index === filled && filled < total
              ? {
                  scale: [1, 1.3, 1],
                  opacity: [0.3, 1, 0.3],
                }
              : {}
          }
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="rounded-full"
          style={{
            width: dotSize,
            height: dotSize,
            background:
              index < filled ? 'var(--accent-primary)' : 'var(--border-subtle)',
          }}
        />
      ))}
    </div>
  );
}
