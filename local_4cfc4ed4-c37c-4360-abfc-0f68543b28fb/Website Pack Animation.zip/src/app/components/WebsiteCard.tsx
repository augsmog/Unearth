import { motion, AnimatePresence } from 'motion/react';
import { Check, Plus } from 'lucide-react';
import { Website } from '../data/websites';
import { ParticleBurst } from './ParticleBurst';

type PackColor = 'gold' | 'blue' | 'purple';

interface WebsiteCardProps {
  website: Website;
  variant?: 'face-up' | 'face-down';
  isKept?: boolean;
  disabled?: boolean;
  onKeepToggle?: () => void;
  onPreview?: () => void;
  className?: string;
  showParticles?: boolean;
  packColor?: PackColor;
}

export function WebsiteCard({
  website,
  variant = 'face-up',
  isKept = false,
  disabled = false,
  onKeepToggle,
  onPreview,
  className = '',
  showParticles = false,
  packColor = 'gold',
}: WebsiteCardProps) {
  // Color scheme based on pack type
  const colorSchemes = {
    gold: {
      primary: '#FFD700',
      border: 'rgba(255, 215, 0, 0.2)',
      shadow: 'rgba(255, 215, 0, 0.1)',
      keptShadow: 'rgba(255, 215, 0, 0.4)',
    },
    blue: {
      primary: '#00D4FF',
      border: 'rgba(0, 212, 255, 0.2)',
      shadow: 'rgba(0, 212, 255, 0.1)',
      keptShadow: 'rgba(0, 212, 255, 0.4)',
    },
    purple: {
      primary: '#B794F6',
      border: 'rgba(183, 148, 246, 0.2)',
      shadow: 'rgba(183, 148, 246, 0.1)',
      keptShadow: 'rgba(183, 148, 246, 0.4)',
    },
  };

  const scheme = colorSchemes[packColor];

  if (variant === 'face-down') {
    return (
      <div
        className={`w-[140px] h-[190px] sm:w-[160px] sm:h-[220px] md:w-[180px] md:h-[250px] lg:w-[200px] lg:h-[280px] rounded-xl overflow-hidden ${className}`}
        style={{
          background: packColor === 'gold'
            ? 'linear-gradient(135deg, #2A1810 0%, #1a1f3a 50%, #0a0e27 100%)'
            : packColor === 'blue'
            ? 'linear-gradient(135deg, #0A1828 0%, #1a2f3a 50%, #0a0e27 100%)'
            : 'linear-gradient(135deg, #1A0A28 0%, #2a1f3a 50%, #0a0e27 100%)',
          border: `2px solid ${scheme.border}`,
          boxShadow: `0 2px 12px rgba(0, 0, 0, 0.3), 0 0 20px ${scheme.shadow} inset`,
        }}
      >
        <div className="w-full h-full flex items-center justify-center relative">
          {/* Corner ornaments */}
          <div className="absolute top-2 left-2 w-6 h-6 border-l border-t opacity-30"
            style={{ borderColor: scheme.primary }} />
          <div className="absolute top-2 right-2 w-6 h-6 border-r border-t opacity-30"
            style={{ borderColor: scheme.primary }} />
          <div className="absolute bottom-2 left-2 w-6 h-6 border-l border-b opacity-30"
            style={{ borderColor: scheme.primary }} />
          <div className="absolute bottom-2 right-2 w-6 h-6 border-r border-b opacity-30"
            style={{ borderColor: scheme.primary }} />
          
          {/* Pattern */}
          <div className="absolute inset-0 opacity-5">
            <div className="absolute top-4 left-4 w-8 h-8 border border-current rotate-45"
              style={{ borderColor: scheme.primary }} />
            <div className="absolute top-12 right-6 w-6 h-6 border border-current rounded-full"
              style={{ borderColor: scheme.primary }} />
            <div className="absolute bottom-12 left-8 w-10 h-10 border border-current rotate-12"
              style={{ borderColor: scheme.primary }} />
            <div className="absolute bottom-4 right-4 w-6 h-6 border border-current rounded-full"
              style={{ borderColor: scheme.primary }} />
          </div>
          
          {/* Center symbol */}
          <div className="relative">
            <div className="w-16 h-16 border-2 border-current rotate-45 opacity-20"
              style={{ borderColor: scheme.primary }}>
              <div className="absolute inset-0 border border-current"
                style={{ borderColor: scheme.primary }} />
            </div>
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-2xl opacity-30"
              style={{ color: scheme.primary }}>
              ?
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      className={`w-[160px] h-[220px] md:w-[200px] md:h-[280px] rounded-xl relative ${className}`}
      style={{
        background: 'linear-gradient(to bottom, var(--bg-surface) 0%, rgba(26, 31, 58, 0.95) 100%)',
        border: isKept ? '2px solid var(--accent-primary)' : `2px solid ${scheme.border}`,
        boxShadow: isKept
          ? '0 4px 16px rgba(0, 0, 0, 0.4), 0 0 32px rgba(233, 69, 96, 0.4)'
          : `0 4px 16px rgba(0, 0, 0, 0.4), 0 0 20px ${scheme.shadow}`,
      }}
    >
      {/* Particle burst effect */}
      <AnimatePresence>
        {showParticles && <ParticleBurst />}
      </AnimatePresence>
      
      {/* Corner decorations */}
      <div className="absolute top-0 left-0 w-4 h-4 border-l border-t opacity-20 z-10"
        style={{ borderColor: scheme.primary }} />
      <div className="absolute top-0 right-0 w-4 h-4 border-r border-t opacity-20 z-10"
        style={{ borderColor: scheme.primary }} />
      
      {/* Category pill - positioned above card in center */}
      <div className="absolute -top-6 left-1/2 -translate-x-1/2 z-20">
        <div
          className="px-3 py-1.5 rounded-full text-[10px] md:text-xs uppercase tracking-wide font-bold whitespace-nowrap"
          style={{
            background: 'rgba(10, 14, 39, 0.95)',
            border: `1.5px solid ${scheme.primary}`,
            color: scheme.primary,
            boxShadow: `0 4px 12px rgba(0, 0, 0, 0.6), 0 0 20px ${scheme.shadow}`,
            backdropFilter: 'blur(8px)',
          }}
        >
          {website.category}
        </div>
      </div>
      
      {/* Thumbnail */}
      <div className="relative w-full h-[55%] overflow-hidden rounded-t-xl">
        <img
          src={website.thumbnail}
          alt={website.title}
          className="w-full h-full object-cover"
        />
        <div
          className="absolute bottom-0 left-0 right-0 h-8"
          style={{
            background: 'linear-gradient(to bottom, transparent, var(--bg-surface))',
          }}
        />
      </div>

      {/* Content */}
      <div className="px-3 py-2 flex flex-col h-[45%]">
        <h3
          className="text-xs md:text-sm font-semibold mb-1 line-clamp-2"
          style={{ color: 'var(--text-primary)' }}
        >
          {website.title}
        </h3>
        
        <p
          className="text-[10px] md:text-xs mb-auto line-clamp-2"
          style={{ color: 'var(--text-secondary)' }}
        >
          {website.description}
        </p>

        {/* Action area */}
        <div className="flex items-center justify-between mt-2">
          <button
            onClick={onPreview}
            className="text-[10px] md:text-xs underline-offset-2 hover:underline"
            style={{ color: scheme.primary, opacity: 0.8 }}
          >
            Preview
          </button>

          <KeepButton
            isKept={isKept}
            disabled={disabled}
            onClick={onKeepToggle}
          />
        </div>
      </div>
    </motion.div>
  );
}

interface KeepButtonProps {
  isKept: boolean;
  disabled: boolean;
  onClick?: () => void;
}

function KeepButton({ isKept, disabled, onClick }: KeepButtonProps) {
  return (
    <motion.button
      whileHover={!disabled ? { scale: 1.1 } : {}}
      whileTap={!disabled ? { scale: 0.95 } : {}}
      onClick={onClick}
      disabled={disabled}
      className="w-8 h-8 rounded-full flex items-center justify-center transition-all"
      style={{
        background: isKept ? 'var(--accent-primary)' : 'transparent',
        border: `2px solid ${isKept ? 'var(--accent-primary)' : disabled ? 'var(--border-subtle)' : 'var(--border-subtle)'}`,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled && !isKept ? 0.5 : 1,
      }}
    >
      {isKept ? (
        <Check size={16} style={{ color: 'white' }} strokeWidth={3} />
      ) : (
        <Plus
          size={16}
          style={{ color: disabled ? 'var(--text-muted)' : 'var(--text-muted)' }}
          strokeWidth={2}
        />
      )}
    </motion.button>
  );
}