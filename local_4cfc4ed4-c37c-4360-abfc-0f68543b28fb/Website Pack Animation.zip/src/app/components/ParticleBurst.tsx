import { motion } from 'motion/react';

interface ParticleBurstProps {
  color?: string;
}

export function ParticleBurst({ color = 'var(--accent-primary)' }: ParticleBurstProps) {
  const particles = Array.from({ length: 6 });

  return (
    <div className="absolute inset-0 pointer-events-none">
      {particles.map((_, i) => {
        const angle = (i * 360) / particles.length;
        const distance = 40;
        const x = Math.cos((angle * Math.PI) / 180) * distance;
        const y = Math.sin((angle * Math.PI) / 180) * distance;

        return (
          <motion.div
            key={i}
            initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
            animate={{
              x,
              y,
              opacity: 0,
              scale: 0,
            }}
            transition={{
              duration: 0.6,
              ease: 'easeOut',
            }}
            className="absolute top-1/2 left-1/2 w-1 h-1 rounded-full"
            style={{ background: color }}
          />
        );
      })}
    </div>
  );
}
