import { useLocation, useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { WebsiteCard } from '../components/WebsiteCard';
import { Header } from '../components/Header';
import { ChevronDown, Flame } from 'lucide-react';
import { Website } from '../data/websites';
import { useState } from 'react';
import { getRandomPack } from '../data/websites';

export default function PostPackSummary() {
  const location = useLocation();
  const navigate = useNavigate();
  const [keptWebsites] = useState<Website[]>(() => {
    // Use passed websites or generate random ones
    return location.state?.keptWebsites?.length > 0
      ? location.state.keptWebsites
      : getRandomPack(3);
  });

  const handleOpenAnother = () => {
    navigate('/');
  };

  const handleViewCollection = () => {
    // In a real app, this would navigate to the collection view
    navigate('/');
  };

  return (
    <div
      className="min-h-screen"
      style={{ background: 'var(--bg-primary)' }}
    >
      <Header streak={3} />

      <div className="pt-14 px-4 min-h-screen flex flex-col items-center justify-center">
        {/* Header text */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <h1
            className="text-3xl md:text-4xl mb-2"
            style={{ color: 'var(--text-primary)' }}
          >
            Nice finds!
          </h1>
          <p
            className="text-sm"
            style={{ color: 'var(--text-secondary)' }}
          >
            Added to your collection
          </p>
        </motion.div>

        {/* Kept cards */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex gap-4 mb-6 flex-wrap justify-center max-w-4xl"
        >
          {keptWebsites.map((website, index) => (
            <motion.div
              key={website.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <WebsiteCard
                website={website}
                variant="face-up"
                isKept={true}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Board selector */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg mb-6"
          style={{
            background: 'var(--bg-elevated)',
            color: 'var(--text-secondary)',
          }}
        >
          <span className="text-sm">Save to: Favorites</span>
          <ChevronDown size={16} />
        </motion.button>

        {/* Action buttons */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="flex flex-col items-center gap-3 w-full max-w-[340px]"
        >
          <button
            onClick={handleOpenAnother}
            className="w-full h-[52px] rounded-xl font-semibold text-sm"
            style={{
              background: 'var(--accent-primary)',
              color: 'white',
            }}
          >
            Open Another Pack
          </button>

          <button
            onClick={handleViewCollection}
            className="text-sm underline-offset-2 hover:underline"
            style={{ color: 'var(--text-muted)' }}
          >
            View Collection
          </button>
        </motion.div>

        {/* Stats nudge */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="mt-8 flex items-center gap-2 text-xs"
          style={{ color: 'var(--text-muted)' }}
        >
          <Flame size={14} style={{ color: 'var(--accent-gold)' }} fill="currentColor" />
          <span>3-day streak! You've discovered 47 sites</span>
        </motion.div>
      </div>
    </div>
  );
}