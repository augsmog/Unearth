import { useEffect, useState } from 'react';
import { useNavigate, useLocation, useSearchParams } from 'react-router';
import { motion } from 'motion/react';
import { Pack } from '../components/Pack';
import { WebsiteCard } from '../components/WebsiteCard';
import { getRandomPack } from '../data/websites';
import { Header } from '../components/Header';

type AnimationPhase = 'shake' | 'tilt' | 'burst' | 'cards-fly' | 'cards-settle' | 'flip' | 'complete';
type PackColor = 'gold' | 'blue' | 'purple';

export default function PackOpeningScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const [phase, setPhase] = useState<AnimationPhase>('shake');
  const [websites] = useState(() => getRandomPack(5));
  
  // Get color from URL params first, then fallback to location.state, then default to gold
  const colorParam = searchParams.get('color') as PackColor | null;
  const packColor: PackColor = colorParam || location.state?.packColor || 'gold';

  console.log('PackOpeningScreen - searchParams color:', colorParam);
  console.log('PackOpeningScreen - location.state:', location.state);
  console.log('PackOpeningScreen - packColor:', packColor);

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase('tilt'), 600),      // Shake then tilt
      setTimeout(() => setPhase('burst'), 1200),     // Burst open
      setTimeout(() => setPhase('cards-fly'), 1400), // Cards fly out
      setTimeout(() => setPhase('cards-settle'), 1900), // Cards settle into position
      setTimeout(() => setPhase('flip'), 2400),      // Cards flip
      setTimeout(() => setPhase('complete'), 3200),  // Complete
      setTimeout(() => {
        navigate('/card-selection', { state: { websites, fromOpening: true, packColor } });
      }, 3500), // Navigate shortly after flip completes
    ];

    return () => timers.forEach(clearTimeout);
  }, [navigate, websites, packColor]);

  return (
    <div
      className="min-h-screen relative overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      <Header streak={3} />

      <div className="pt-14 min-h-screen flex items-center justify-center px-4">
        {/* Phase 1-3: Pack shaking, tilting, and bursting */}
        {(phase === 'shake' || phase === 'tilt' || phase === 'burst') && (
          <div className="relative">
            {/* Pack shake animation */}
            {phase === 'shake' && (
              <motion.div
                animate={{
                  rotate: [0, -2, 2, -2, 2, 0],
                  scale: [1, 1.02, 1, 1.02, 1],
                }}
                transition={{
                  duration: 0.6,
                  ease: "easeInOut",
                }}
              >
                <Pack variant="sealed" color={packColor} />
              </motion.div>
            )}

            {/* Pack tilt and rotate */}
            {phase === 'tilt' && (
              <motion.div
                initial={{ rotateY: 0, rotateX: 0, scale: 1 }}
                animate={{
                  rotateY: 25,
                  rotateX: -10,
                  scale: 1.1,
                }}
                transition={{
                  duration: 0.6,
                  ease: "easeOut",
                }}
                style={{
                  transformStyle: 'preserve-3d',
                  perspective: 1000,
                }}
              >
                <Pack variant="sealed" color={packColor} />
              </motion.div>
            )}

            {/* Burst effect */}
            {phase === 'burst' && (
              <>
                <motion.div
                  initial={{ scale: 1.1, rotateY: 25, rotateX: -10 }}
                  animate={{ scale: 1.3, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  style={{
                    transformStyle: 'preserve-3d',
                  }}
                >
                  <Pack variant="opening" color={packColor} />
                </motion.div>

                {/* Central explosion glow */}
                <motion.div
                  initial={{ scale: 0, opacity: 0 }}
                  animate={{ scale: 3, opacity: [0, 1, 0] }}
                  transition={{ duration: 0.4 }}
                  className="absolute inset-0 flex items-center justify-center pointer-events-none"
                >
                  <div
                    className="w-64 h-64 rounded-full blur-3xl"
                    style={{
                      background: packColor === 'gold' 
                        ? 'radial-gradient(circle, #FFD700 0%, var(--accent-primary) 50%, transparent 70%)'
                        : packColor === 'blue'
                        ? 'radial-gradient(circle, #00D4FF 0%, var(--accent-primary) 50%, transparent 70%)'
                        : 'radial-gradient(circle, #B794F6 0%, var(--accent-primary) 50%, transparent 70%)',
                    }}
                  />
                </motion.div>

                {/* Light rays */}
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scaleY: 0, opacity: 0 }}
                    animate={{ scaleY: 1, opacity: [0, 0.6, 0] }}
                    transition={{ duration: 0.4, delay: 0.05 * i }}
                    className="absolute top-1/2 left-1/2 w-1 h-96 origin-bottom"
                    style={{
                      background: packColor === 'gold'
                        ? 'linear-gradient(to top, #FFD700, transparent)'
                        : packColor === 'blue'
                        ? 'linear-gradient(to top, #00D4FF, transparent)'
                        : 'linear-gradient(to top, #B794F6, transparent)',
                      transform: `rotate(${i * 45}deg) translateX(-50%)`,
                      marginLeft: '-0.125rem',
                    }}
                  />
                ))}
              </>
            )}
          </div>
        )}

        {/* Phase 4-7: Cards flying out and settling */}
        {(phase === 'cards-fly' || phase === 'cards-settle' || phase === 'flip' || phase === 'complete') && (
          <div className="flex items-center justify-center gap-1 sm:gap-2 md:gap-3 lg:gap-4 w-full px-2 sm:px-4">
            {websites.map((website, index) => {
              // Create responsive scatter positions
              const scatterPositions = [
                { x: -80, y: -60, rotate: -25 },   // Top left (mobile)
                { x: -40, y: -80, rotate: -12 },   // Top mid-left
                { x: 0, y: -90, rotate: 0 },       // Top center
                { x: 40, y: -80, rotate: 12 },     // Top mid-right
                { x: 80, y: -60, rotate: 25 },     // Top right (mobile)
              ];

              // Desktop scatter positions (wider spread)
              const desktopScatterPositions = [
                { x: -180, y: -100, rotate: -25 },
                { x: -90, y: -130, rotate: -12 },
                { x: 0, y: -140, rotate: 0 },
                { x: 90, y: -130, rotate: 12 },
                { x: 180, y: -100, rotate: 25 },
              ];

              // Tablet scatter positions (medium spread)
              const tabletScatterPositions = [
                { x: -120, y: -80, rotate: -25 },
                { x: -60, y: -100, rotate: -12 },
                { x: 0, y: -110, rotate: 0 },
                { x: 60, y: -100, rotate: 12 },
                { x: 120, y: -80, rotate: 25 },
              ];
              
              // Choose scatter position based on screen width
              const getScatter = () => {
                if (typeof window !== 'undefined') {
                  if (window.innerWidth >= 1024) return desktopScatterPositions[index];
                  if (window.innerWidth >= 768) return tabletScatterPositions[index];
                }
                return scatterPositions[index];
              };
              const scatter = getScatter();
              
              // Final settled positions - responsive spacing
              // Mobile: stack or very tight, Tablet: moderate, Desktop: spread out
              const getFinalX = () => {
                if (typeof window !== 'undefined') {
                  if (window.innerWidth >= 1440) return (index - 2) * 240; // Desktop XL
                  if (window.innerWidth >= 1024) return (index - 2) * 180; // Desktop
                  if (window.innerWidth >= 768) return (index - 2) * 110;  // Tablet
                  if (window.innerWidth >= 640) return (index - 2) * 85;   // Large mobile
                }
                return (index - 2) * 65; // Small mobile
              };
              const finalX = getFinalX();

              return (
                <motion.div
                  key={website.id}
                  initial={{
                    x: 0,
                    y: 0,
                    rotate: 0,
                    scale: 0.3,
                    opacity: 0,
                    z: 0,
                  }}
                  animate={
                    phase === 'cards-fly'
                      ? {
                          x: scatter.x,
                          y: scatter.y,
                          rotate: scatter.rotate,
                          scale: 0.7,
                          opacity: 1,
                        }
                      : phase === 'cards-settle'
                      ? {
                          x: finalX,
                          y: 0,
                          rotate: 0,
                          scale: 1,
                          opacity: 1,
                        }
                      : {
                          x: finalX,
                          y: 0,
                          rotate: 0,
                          scale: 1,
                          opacity: 1,
                        }
                  }
                  transition={{
                    duration: phase === 'cards-fly' ? 0.5 : 0.5,
                    delay: index * 0.05,
                    ease: phase === 'cards-fly' ? [0.34, 1.56, 0.64, 1] : 'easeOut',
                  }}
                  style={{
                    transformStyle: 'preserve-3d',
                  }}
                >
                  {/* Card with flip animation */}
                  {(phase === 'flip' || phase === 'complete') ? (
                    <motion.div
                      initial={{ rotateY: 180 }}
                      animate={{ rotateY: 0 }}
                      transition={{
                        duration: 0.6,
                        delay: index * 0.08,
                        ease: 'easeOut',
                      }}
                      style={{
                        transformStyle: 'preserve-3d',
                      }}
                    >
                      <WebsiteCard website={website} variant="face-up" packColor={packColor} />
                      
                      {/* Reveal glow on flip */}
                      {phase === 'flip' && (
                        <motion.div
                          initial={{ scale: 0, opacity: 1 }}
                          animate={{ scale: 2.5, opacity: 0 }}
                          transition={{
                            duration: 0.6,
                            delay: index * 0.08 + 0.3,
                          }}
                          className="absolute inset-0 pointer-events-none"
                        >
                          <div
                            className="absolute inset-0 rounded-xl"
                            style={{
                              background: packColor === 'gold'
                                ? 'radial-gradient(circle, #FFD700 0%, transparent 60%)'
                                : packColor === 'blue'
                                ? 'radial-gradient(circle, #00D4FF 0%, transparent 60%)'
                                : 'radial-gradient(circle, #B794F6 0%, transparent 60%)',
                            }}
                          />
                        </motion.div>
                      )}
                    </motion.div>
                  ) : (
                    <WebsiteCard website={website} variant="face-down" packColor={packColor} />
                  )}
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Background ambient particles during burst */}
        {phase === 'burst' && (
          <>
            {[...Array(20)].map((_, i) => {
              const angle = (i * 360) / 20;
              const distance = 200 + Math.random() * 100;
              const x = Math.cos((angle * Math.PI) / 180) * distance;
              const y = Math.sin((angle * Math.PI) / 180) * distance;
              
              const particleColor = packColor === 'gold'
                ? '#FFD700'
                : packColor === 'blue'
                ? '#00D4FF'
                : '#B794F6';
              
              return (
                <motion.div
                  key={`particle-${i}`}
                  initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                  animate={{
                    x,
                    y,
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                  }}
                  transition={{
                    duration: 0.8,
                    delay: Math.random() * 0.2,
                    ease: 'easeOut',
                  }}
                  className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full"
                  style={{
                    background: i % 2 === 0 ? particleColor : 'var(--accent-primary)',
                  }}
                />
              );
            })}
          </>
        )}
      </div>
    </div>
  );
}