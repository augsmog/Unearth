import { useNavigate } from 'react-router';
import { Pack } from '../components/Pack';
import { CounterDots } from '../components/CounterDots';
import { InterestPill } from '../components/InterestPill';
import { Header } from '../components/Header';
import { motion } from 'motion/react';
import { ExternalLink, Sparkles } from 'lucide-react';
import { useState } from 'react';

export default function PackReadyScreen() {
  const navigate = useNavigate();
  const [selectedPack, setSelectedPack] = useState<'gold' | 'blue' | 'purple'>('gold');

  const interests = ['Indie Tools', 'Design', 'AI', 'Startups'];
  const packsRemaining = 2;
  const totalPacks = 3;

  const handleOpenPack = () => {
    console.log('PackReadyScreen - Opening pack with color:', selectedPack);
    navigate(`/pack-opening?color=${selectedPack}`);
  };

  return (
    <div
      className="min-h-screen"
      style={{ background: 'var(--bg-primary)' }}
    >
      <Header streak={3} />

      <div className="pt-14 px-4 min-h-screen flex flex-col items-center justify-center">
        {/* Tagline - above packs */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-12 px-4"
        >
          <p className="text-2xl md:text-4xl font-bold tracking-wide mb-2"
            style={{ 
              color: 'var(--text-primary)',
              fontFamily: 'ui-monospace, "Cascadia Code", "Source Code Pro", Menlo, Consolas, "DejaVu Sans Mono", monospace',
              textShadow: '0 0 20px rgba(255, 107, 157, 0.3)',
              letterSpacing: '0.05em'
            }}
          >
            THE INTERNET IS CLUTTERED
          </p>
          <p className="text-2xl md:text-4xl font-bold tracking-wide"
            style={{ 
              color: 'var(--accent-primary)',
              fontFamily: 'ui-monospace, "Cascadia Code", "Source Code Pro", Menlo, Consolas, "DejaVu Sans Mono", monospace',
              textShadow: '0 0 20px rgba(255, 107, 157, 0.5)',
              letterSpacing: '0.05em'
            }}
          >
            LET US CURATE FOR YOU
          </p>
        </motion.div>

        {/* Pack selection carousel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="flex items-center justify-center gap-3 md:gap-6 mb-8"
        >
          <Pack 
            color="purple" 
            isSelected={selectedPack === 'purple'} 
            onClick={() => setSelectedPack('purple')}
          />
          <Pack 
            color="gold" 
            isSelected={selectedPack === 'gold'} 
            onClick={() => setSelectedPack('gold')}
          />
          <Pack 
            color="blue" 
            isSelected={selectedPack === 'blue'} 
            onClick={() => setSelectedPack('blue')}
          />
        </motion.div>

        {/* Open Pack button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleOpenPack}
          className="relative w-full max-w-[340px] h-[56px] rounded-xl font-bold text-base overflow-hidden"
          style={{
            background: 'linear-gradient(135deg, var(--accent-primary) 0%, #E94560 100%)',
            color: 'white',
            boxShadow: '0 8px 32px rgba(233, 69, 96, 0.5), 0 0 20px rgba(233, 69, 96, 0.3)',
          }}
        >
          {/* Animated shimmer effect */}
          <motion.div
            animate={{
              x: ['-200%', '200%'],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'linear',
            }}
            className="absolute inset-0 w-1/3"
            style={{
              background: 'linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent)',
            }}
          />
          
          <span className="relative">
            Let's Explore!
          </span>
        </motion.button>

        {/* Interest tags */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-6 flex flex-wrap gap-2 justify-center max-w-[320px]"
        >
          {interests.map((interest) => (
            <InterestPill key={interest} label={interest} />
          ))}
        </motion.div>

        {/* Demo navigation */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.9 }}
          className="mt-12 text-center"
        >
          <p
            className="text-xs mb-3"
            style={{ color: 'var(--text-muted)' }}
          >
            Or jump to a specific state:
          </p>
          <div className="flex flex-wrap gap-2 justify-center text-xs">
            <button
              onClick={() => navigate('/card-selection', { state: { websites: [] } })}
              className="px-3 py-1.5 rounded-lg flex items-center gap-1"
              style={{ background: 'var(--bg-elevated)', color: 'var(--text-secondary)' }}
            >
              Card Selection <ExternalLink size={12} />
            </button>
            <button
              onClick={() => navigate('/summary', { state: { keptWebsites: [] } })}
              className="px-3 py-1.5 rounded-lg flex items-center gap-1"
              style={{ background: 'var(--bg-elevated)', color: 'var(--text-secondary)' }}
            >
              Summary <ExternalLink size={12} />
            </button>
            <button
              onClick={() => navigate('/empty')}
              className="px-3 py-1.5 rounded-lg flex items-center gap-1"
              style={{ background: 'var(--bg-elevated)', color: 'var(--text-secondary)' }}
            >
              Empty State <ExternalLink size={12} />
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}