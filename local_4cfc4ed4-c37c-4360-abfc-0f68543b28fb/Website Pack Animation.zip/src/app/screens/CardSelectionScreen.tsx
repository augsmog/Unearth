import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { WebsiteCard } from '../components/WebsiteCard';
import { CounterDots } from '../components/CounterDots';
import { Header } from '../components/Header';
import { Website } from '../data/websites';
import { getRandomPack } from '../data/websites';

type PackColor = 'gold' | 'blue' | 'purple';

export default function CardSelectionScreen() {
  const location = useLocation();
  const navigate = useNavigate();
  const [websites] = useState<Website[]>(() => {
    // Use passed websites or generate random ones
    return location.state?.websites?.length > 0 
      ? location.state.websites 
      : getRandomPack(5);
  });
  
  const [keptCards, setKeptCards] = useState<Set<string>>(new Set());
  const [justKept, setJustKept] = useState<string | null>(null);
  const maxKeep = 3;
  const minKeep = 2;
  
  // Check if coming from pack opening animation
  const fromOpening = location.state?.fromOpening || false;
  const packColor: PackColor = location.state?.packColor || 'gold';

  // Clear the particle effect after animation
  useEffect(() => {
    if (justKept) {
      const timer = setTimeout(() => setJustKept(null), 600);
      return () => clearTimeout(timer);
    }
  }, [justKept]);

  const handleKeepToggle = (id: string) => {
    setKeptCards((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else if (newSet.size < maxKeep) {
        newSet.add(id);
        setJustKept(id); // Trigger particle effect
      }
      return newSet;
    });
  };

  const handleConfirm = () => {
    if (keptCards.size >= minKeep) {
      const kept = websites.filter((w) => keptCards.has(w.id));
      navigate('/summary', { state: { keptWebsites: kept } });
    }
  };

  const handleSkip = () => {
    if (keptCards.size >= minKeep) {
      const kept = websites.filter((w) => keptCards.has(w.id));
      navigate('/summary', { state: { keptWebsites: kept } });
    }
  };

  const canConfirm = keptCards.size >= minKeep;

  return (
    <div
      className="min-h-screen"
      style={{ background: 'var(--bg-primary)' }}
    >
      <Header streak={3} />

      <div className="pt-14 pb-8 px-4 min-h-screen flex flex-col">
        {/* Mobile: Horizontal scroll */}
        <div className="md:hidden flex-1 flex items-center justify-center">
          <motion.div 
            className="w-full overflow-x-auto pb-4 pt-6 hide-scrollbar"
            initial={fromOpening ? { opacity: 1 } : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex gap-4 px-4 justify-center">
              {websites.map((website, index) => {
                // Start from pack opening position if coming from animation
                const isMobile = window.innerWidth < 768;
                const startX = fromOpening ? (index - 2) * (isMobile ? 65 : 120) : 0;
                
                return (
                  <motion.div
                    key={website.id}
                    initial={fromOpening ? { 
                      x: startX, 
                      y: 0,
                    } : { 
                      opacity: 0,
                      x: 0, 
                    }}
                    animate={{ 
                      x: 0, 
                      y: 0,
                      opacity: 1,
                    }}
                    transition={{ 
                      duration: 0.6,
                      delay: fromOpening ? index * 0.05 : index * 0.1,
                      ease: 'easeOut',
                    }}
                  >
                    <WebsiteCard
                      website={website}
                      variant="face-up"
                      isKept={keptCards.has(website.id)}
                      disabled={!keptCards.has(website.id) && keptCards.size >= maxKeep}
                      onKeepToggle={() => handleKeepToggle(website.id)}
                      showParticles={justKept === website.id}
                      packColor={packColor}
                    />
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </div>

        {/* Desktop: All cards visible */}
        <div className="hidden md:flex flex-1 items-center justify-center gap-2 lg:gap-4 px-4">
          {websites.map((website, index) => {
            // Start from pack opening position if coming from animation
            const getStartX = () => {
              if (!fromOpening) return 0;
              if (typeof window !== 'undefined') {
                if (window.innerWidth >= 1440) return (index - 2) * 240;
                if (window.innerWidth >= 1024) return (index - 2) * 180;
                if (window.innerWidth >= 768) return (index - 2) * 110;
              }
              return (index - 2) * 110;
            };
            const startX = getStartX();
            
            return (
              <motion.div
                key={website.id}
                initial={fromOpening ? { 
                  x: startX, 
                  y: 0,
                } : { 
                  opacity: 0,
                  y: 20,
                }}
                animate={{ 
                  x: 0, 
                  y: 0,
                  opacity: 1,
                }}
                transition={{ 
                  duration: 0.6,
                  delay: fromOpening ? index * 0.05 : index * 0.1,
                  ease: 'easeOut',
                }}
              >
                <WebsiteCard
                  website={website}
                  variant="face-up"
                  isKept={keptCards.has(website.id)}
                  disabled={!keptCards.has(website.id) && keptCards.size >= maxKeep}
                  onKeepToggle={() => handleKeepToggle(website.id)}
                  showParticles={justKept === website.id}
                  packColor={packColor}
                />
              </motion.div>
            );
          })}
        </div>

        {/* Bottom controls */}
        <div className="flex flex-col items-center gap-6 mt-6">
          {/* Keep counter */}
          <div className="flex flex-col items-center gap-2">
            <p
              className="text-sm"
              style={{ color: 'var(--text-secondary)' }}
            >
              Kept {keptCards.size} of {maxKeep}
            </p>
            <CounterDots total={maxKeep} filled={keptCards.size} size="medium" />
          </div>

          {/* Confirm button */}
          <AnimatePresence mode="wait">
            {canConfirm ? (
              <motion.button
                key="confirm"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleConfirm}
                className="w-full max-w-[340px] h-[52px] rounded-xl font-semibold text-sm"
                style={{
                  background: 'var(--accent-primary)',
                  color: 'white',
                }}
              >
                Add to Collection
              </motion.button>
            ) : (
              <motion.div
                key="disabled"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="w-full max-w-[340px] h-[52px] rounded-xl font-semibold text-sm flex items-center justify-center"
                style={{
                  background: 'var(--bg-elevated)',
                  color: 'var(--text-muted)',
                }}
              >
                Keep at least {minKeep}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Skip button */}
          {canConfirm && (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              onClick={handleSkip}
              className="text-xs underline-offset-2 hover:underline"
              style={{ color: 'var(--text-muted)' }}
            >
              Skip remaining
            </motion.button>
          )}
        </div>
      </div>

      <style>{`
        .hide-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .hide-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}