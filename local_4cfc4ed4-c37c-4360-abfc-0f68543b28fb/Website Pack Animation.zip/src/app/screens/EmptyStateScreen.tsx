import { useNavigate } from 'react-router';
import { motion } from 'motion/react';
import { Header } from '../components/Header';
import { Hourglass } from 'lucide-react';

export default function EmptyStateScreen() {
  const navigate = useNavigate();

  return (
    <div
      className="min-h-screen"
      style={{ background: 'var(--bg-primary)' }}
    >
      <Header streak={3} />

      <div className="pt-14 px-4 min-h-screen flex flex-col items-center justify-center">
        {/* Illustration */}
        <motion.div
          animate={{
            y: [0, -8, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="mb-8"
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              background: 'var(--bg-elevated)',
            }}
          >
            <Hourglass
              size={40}
              style={{ color: 'var(--text-muted)' }}
              strokeWidth={1.5}
            />
          </div>
        </motion.div>

        {/* Text */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 max-w-sm"
        >
          <h1
            className="text-2xl md:text-3xl mb-3"
            style={{ color: 'var(--text-primary)' }}
          >
            All packed out for today!
          </h1>
          <p
            className="text-sm"
            style={{ color: 'var(--text-secondary)' }}
          >
            Your packs refresh tomorrow at midnight
          </p>
        </motion.div>

        {/* Alternative actions */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col items-center gap-3 w-full max-w-[340px]"
        >
          <button
            onClick={() => navigate('/')}
            className="w-full h-[52px] rounded-xl font-semibold text-sm"
            style={{
              background: 'var(--accent-primary)',
              color: 'white',
            }}
          >
            Browse your boards
          </button>

          <button
            onClick={() => navigate('/')}
            className="text-sm underline-offset-2 hover:underline"
            style={{ color: 'var(--text-muted)' }}
          >
            Explore public boards
          </button>
        </motion.div>
      </div>
    </div>
  );
}