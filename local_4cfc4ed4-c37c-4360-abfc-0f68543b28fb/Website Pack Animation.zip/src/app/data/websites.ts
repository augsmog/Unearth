export interface Website {
  id: string;
  title: string;
  description: string;
  category: string;
  thumbnail: string;
  url: string;
}

export const websiteDatabase: Website[] = [
  {
    id: '1',
    title: 'Raycast — Supercharged Productivity',
    description: 'A blazingly fast, totally extendable launcher for Mac',
    category: 'Indie Tool',
    thumbnail: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=300&fit=crop',
    url: 'https://raycast.com',
  },
  {
    id: '2',
    title: 'Linear — The Issue Tracker You\'ll Enjoy Using',
    description: 'Built for modern software teams. Streamline issues, sprints, and product roadmaps.',
    category: 'Productivity',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
    url: 'https://linear.app',
  },
  {
    id: '3',
    title: 'Notation — AI-Powered Note Taking',
    description: 'Smart notes that connect your thoughts and surface insights automatically',
    category: 'AI',
    thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400&h=300&fit=crop',
    url: 'https://notation.app',
  },
  {
    id: '4',
    title: 'Cosmos — Beautiful Design Resources',
    description: 'Curated collection of the best UI patterns, illustrations, and design systems',
    category: 'Design',
    thumbnail: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=300&fit=crop',
    url: 'https://cosmos.design',
  },
  {
    id: '5',
    title: 'Midnight Snacks — Indie Hacker Stories',
    description: 'Raw, honest stories from founders building profitable internet businesses',
    category: 'Blog',
    thumbnail: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=400&h=300&fit=crop',
    url: 'https://midnightsnacks.blog',
  },
  {
    id: '6',
    title: 'Tinybird — Real-time Data Infrastructure',
    description: 'Ingest, transform, and publish data at any scale with SQL',
    category: 'Developer Tool',
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=300&fit=crop',
    url: 'https://tinybird.co',
  },
  {
    id: '7',
    title: 'Contra — Freelance Without Limits',
    description: 'Build your independent career with portfolios, contracts, and payments in one place',
    category: 'Startup',
    thumbnail: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=300&fit=crop',
    url: 'https://contra.com',
  },
  {
    id: '8',
    title: 'Gamma — AI Presentation Maker',
    description: 'Create beautiful presentations, documents, and websites with AI',
    category: 'AI',
    thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=400&h=300&fit=crop',
    url: 'https://gamma.app',
  },
  {
    id: '9',
    title: 'Campsite — Team Communication Done Right',
    description: 'Async collaboration for design teams. Share work, gather feedback, build alignment.',
    category: 'Design',
    thumbnail: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=400&h=300&fit=crop',
    url: 'https://campsite.design',
  },
  {
    id: '10',
    title: 'Sublime — New Tab for Focused Work',
    description: 'Beautiful new tab experience with productivity timers and ambient soundscapes',
    category: 'Indie Tool',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=400&h=300&fit=crop',
    url: 'https://sublime.app',
  },
  {
    id: '11',
    title: 'PostHog — Product Analytics for Engineers',
    description: 'Open-source product analytics you can self-host. No need for a separate analytics tool.',
    category: 'Developer Tool',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop',
    url: 'https://posthog.com',
  },
  {
    id: '12',
    title: 'Patterns — The Newsletter for Makers',
    description: 'Weekly dose of tech, design, and startup insights from Silicon Valley',
    category: 'Blog',
    thumbnail: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=400&h=300&fit=crop',
    url: 'https://patterns.substack.com',
  },
  {
    id: '13',
    title: 'Obsidian — Your Second Brain',
    description: 'A powerful knowledge base on top of a local folder of plain text Markdown files',
    category: 'Productivity',
    thumbnail: 'https://images.unsplash.com/photo-1517842645767-c639042777db?w=400&h=300&fit=crop',
    url: 'https://obsidian.md',
  },
  {
    id: '14',
    title: 'Luma — Beautiful Event Pages',
    description: 'Host events that bring people together. Calendar integrations, RSVP tracking, and more.',
    category: 'Startup',
    thumbnail: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=400&h=300&fit=crop',
    url: 'https://lu.ma',
  },
  {
    id: '15',
    title: 'v0 — Generative UI by Vercel',
    description: 'Generate UI with simple text prompts. Copy, paste, ship.',
    category: 'AI',
    thumbnail: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=400&h=300&fit=crop',
    url: 'https://v0.dev',
  },
];

export function getRandomPack(count: number = 5): Website[] {
  const shuffled = [...websiteDatabase].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}
