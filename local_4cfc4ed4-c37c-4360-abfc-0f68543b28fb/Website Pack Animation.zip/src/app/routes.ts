import { createBrowserRouter } from 'react-router';
import PackReadyScreen from './screens/PackReadyScreen';
import PackOpeningScreen from './screens/PackOpeningScreen';
import CardSelectionScreen from './screens/CardSelectionScreen';
import PostPackSummary from './screens/PostPackSummary';
import EmptyStateScreen from './screens/EmptyStateScreen';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: PackReadyScreen,
  },
  {
    path: '/pack-opening',
    Component: PackOpeningScreen,
  },
  {
    path: '/card-selection',
    Component: CardSelectionScreen,
  },
  {
    path: '/summary',
    Component: PostPackSummary,
  },
  {
    path: '/empty',
    Component: EmptyStateScreen,
  },
]);