
  # Website Pack Animation

  This is a code bundle for Website Pack Animation. The original project is available at https://www.figma.com/design/oNOKbycxqjswlbiSkJN2lS/Website-Pack-Animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  